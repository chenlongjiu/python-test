Use Trie to store data 

Run it with command :  python findLongestWord.py

result including longest word and second longest word and total compound words number